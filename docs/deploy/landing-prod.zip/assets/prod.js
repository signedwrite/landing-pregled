// LAND ING – production: cookie consent, conversion tracking, contact form, legacy #! links
(function () {
  var L = (document.body.dataset.lang || 'hr');
  var TXT = {
    hr: {c: 'Koristimo kolačiće za mjerenje posjeta i učinkovitosti oglasa. Možete prihvatiti sve ili samo nužne.', a: 'Prihvaćam', n: 'Samo nužni', p: 'Politika kolačića',
         sending: 'Šaljem…', ok: 'Hvala! Vaš upit je poslan. Javit ćemo vam se u najkraćem roku.', err: 'Slanje nije uspjelo. Molimo nazovite nas na 092 233 5366 ili pišite na office@landing.hr.'},
    en: {c: 'We use cookies to measure visits and ad performance. You can accept all or only necessary cookies.', a: 'Accept', n: 'Necessary only', p: 'Cookie policy',
         sending: 'Sending…', ok: 'Thank you! Your enquiry has been sent. We will get back to you shortly.', err: 'Sending failed. Please call +385 92 233 5366 or email office@landing.hr.'},
    de: {c: 'Wir verwenden Cookies zur Messung von Besuchen und Anzeigenleistung. Sie können alle oder nur notwendige akzeptieren.', a: 'Akzeptieren', n: 'Nur notwendige', p: 'Cookie-Richtlinie',
         sending: 'Wird gesendet…', ok: 'Vielen Dank! Ihre Anfrage wurde gesendet. Wir melden uns in Kürze.', err: 'Senden fehlgeschlagen. Bitte rufen Sie +385 92 233 5366 an oder schreiben Sie an office@landing.hr.'}
  }[L] || {};
  function g() { if (window.gtag) gtag.apply(null, arguments); }
  var SEND_TO = 'AW-16818339484/9NYOCPL1t5oaEJz9zdM-';
  // --- cookie banner (Consent Mode v2) ---
  var cc = null; try { cc = localStorage.getItem('cc'); } catch (e) {}
  if (!cc) {
    var b = document.createElement('div'); b.className = 'cc-bar'; b.setAttribute('role', 'dialog'); b.setAttribute('aria-label', TXT.p);
    b.innerHTML = '<p>' + TXT.c + ' <a href="/cookie-policy-eu/">' + TXT.p + '</a></p><div><button type="button" class="btn btn-line cc-n">' + TXT.n + '</button><button type="button" class="btn cc-a">' + TXT.a + '</button></div>';
    document.body.appendChild(b);
    b.querySelector('.cc-a').onclick = function () { try { localStorage.setItem('cc', 'all'); } catch (e) {}
      g('consent', 'update', {ad_storage: 'granted', ad_user_data: 'granted', ad_personalization: 'granted', analytics_storage: 'granted'}); b.remove(); };
    b.querySelector('.cc-n').onclick = function () { try { localStorage.setItem('cc', 'necessary'); } catch (e) {} b.remove(); };
  }
  // --- conversions: phone / e-mail clicks ---
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"], a[href^="mailto:"]') : null;
    if (!a) return;
    var tel = a.href.indexOf('tel:') === 0;
    g('event', 'conversion', {send_to: SEND_TO, event_category: tel ? 'klik_telefon' : 'klik_email'});
    g('event', tel ? 'click_phone' : 'click_email', {link_url: a.href});
  }, true);
  // --- contact form ---
  document.querySelectorAll('form[data-endpoint]').forEach(function (f) {
    var page = document.createElement('input'); page.type = 'hidden'; page.name = 'page'; page.value = location.pathname; f.appendChild(page);
    var msg = document.createElement('p'); msg.className = 'form-msg'; msg.setAttribute('role', 'status'); f.appendChild(msg);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = f.querySelector('button[type=submit]'); var old = btn.textContent; btn.disabled = true; btn.textContent = TXT.sending;
      fetch(f.dataset.endpoint, {method: 'POST', body: new FormData(f), headers: {'Accept': 'application/json'}})
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (!j.ok) throw new Error(j.error || 'fail');
          msg.textContent = TXT.ok; msg.className = 'form-msg ok'; f.reset();
          g('event', 'conversion', {send_to: SEND_TO, event_category: 'kontakt_forma'});
          g('event', 'generate_lead', {form: 'kontakt', page: location.pathname});
        })
        .catch(function () { msg.textContent = TXT.err; msg.className = 'form-msg err'; })
        .finally(function () { btn.disabled = false; btn.textContent = old; });
    });
  });
  // --- legacy one-page links from the old site (landing.hr/#!/kontakt etc.) ---
  var h = location.hash;
  if (h && h.indexOf('#!/') === 0) {
    var k = h.slice(3).replace(/\/$/, '');
    var map = {kontakt: '#kontakt', contact: '#kontakt', 'posalji-poruku': '#kontakt', services: '/usluge/', usluge: '/usluge/', about: '/o-nama/', 'o-nama': '/o-nama/', blog: '/news/'};
    var t = map[k] || '';
    if (t.charAt(0) === '/') location.replace(t);
    else if (t) { history.replaceState(null, '', location.pathname + location.search + t); var el = document.querySelector(t); if (el) setTimeout(function () { el.scrollIntoView(); }, 50); }
  }
})();
