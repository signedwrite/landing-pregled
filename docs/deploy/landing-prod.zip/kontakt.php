<?php
// LAND ING d.o.o. – contact form handler (sends to office@landing.hr, keeps a backup log outside the web root)
header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex');
date_default_timezone_set('Europe/Zagreb');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); echo '{"ok":false}'; exit; }
function f($k, $n = 300) { $v = (string)($_POST[$k] ?? ''); $v = str_replace(["\r", "\n", "\0"], ' ', $v); return trim(mb_substr($v, 0, $n, 'UTF-8')); }
// honeypot (bots fill the hidden "website" field)
if (f('website') !== '') { echo '{"ok":true}'; exit; }
$ime = f('ime', 120); $email = f('email', 160); $tel = f('telefon', 60); $cest = f('cestica', 200); $page = f('page', 300);
$poruka = trim(mb_substr(str_replace("\0", '', (string)($_POST['poruka'] ?? '')), 0, 5000, 'UTF-8'));
if ($ime === '' || $poruka === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { http_response_code(400); echo '{"ok":false,"error":"invalid"}'; exit; }
// simple rate limit: max 6 messages per IP per hour
$ip = $_SERVER['REMOTE_ADDR'] ?? '0';
$home = dirname($_SERVER['DOCUMENT_ROOT']);
$rl = sys_get_temp_dir() . '/landing_rl_' . md5($ip);
$hits = array_filter(explode(',', @file_get_contents($rl) ?: ''), function ($t) { return $t && $t > time() - 3600; });
if (count($hits) >= 6) { http_response_code(429); echo '{"ok":false,"error":"rate"}'; exit; }
$hits[] = time(); @file_put_contents($rl, implode(',', $hits));
$body = "Novi upit s web stranice landing.hr\n\n"
      . "Ime: $ime\nE-mail: $email\nTelefon: " . ($tel ?: '-') . "\nKatastarska čestica / k.o.: " . ($cest ?: '-') . "\nStranica: " . ($page ?: '-') . "\n\n"
      . "Poruka:\n$poruka\n\n--\nPoslano: " . date('d.m.Y. H:i') . " | IP: $ip\n";
$subject = '=?UTF-8?B?' . base64_encode('Upit s web stranice – ' . $ime) . '?=';
$headers = "From: LAND ING web <noreply@landing.hr>\r\nReply-To: " . $email . "\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n";
$sent = @mail('office@landing.hr', $subject, $body, $headers, '-fnoreply@landing.hr');
// backup copy of every enquiry outside public_html, so nothing is lost even if mail fails
@file_put_contents($home . '/landing_upiti.log', str_repeat('=', 40) . "\n" . $body . 'mail: ' . ($sent ? 'OK' : 'FAIL') . "\n", FILE_APPEND | LOCK_EX);
echo json_encode(['ok' => (bool)$sent]);
