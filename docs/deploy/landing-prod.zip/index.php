<?php
// Stara WordPress naslovnica je zamijenjena statičkom stranicom; sve što stigne ovdje je nepostojeća adresa.
http_response_code(404);
header('Content-Type: text/html; charset=utf-8');
readfile(__DIR__ . '/404.html');
